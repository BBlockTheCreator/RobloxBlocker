if (window.location.hostname === "www.roblox.com") {
  // Entfernt gesamten alten Inhalt
  document.head.innerHTML = '';
  document.body.innerHTML = '';

  // Neues Stylesheet einfügen
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = chrome.runtime.getURL('style.css');
  document.head.appendChild(link);

  // HTML-Struktur einfügen
  const container = document.createElement('div');
  container.innerHTML = `
    <div id="clouds">
      <div class="cloud x1"></div>
      <div class="cloud x2"></div>
      <div class="cloud x3"></div>
      <div class="cloud x4"></div>
      <div class="cloud x5"></div>
    </div>

    <div class="c">
      <div class="_404">403</div>
      <hr>
      <div class="_1">ACCESS BLOCKED</div>
      <div class="_2">Roblox is not allowed right now</div>
      <div class="blocker">⚠️ Roblox blocked by <b>SteinGuard</b></div>
    </div>
  `;
  document.body.appendChild(container);
}
